/***************************************************************************
 *   Copyright (C) 2007 by Lucas Vinicius Hartmann                         *
 *   lucas.hartmann@gmail.com                                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

//pvGenerator.h
#ifndef PVGEN_H
#define PVGEN_H
#include <cmath>

class pvGenerator {
	static const double q;
	static const double K;
	static const double e;
	// Referências padrão
	double isref;  // Valor da fonte de corrente para insolação padrão.
	double gref;   // Insolação padrão (W/m²).
	double i0ref;  // Ganho de corrente padrão. Modelo do Diodo paralelo.
	double Tref;   // Temperatura padrão (K). Modelo do Diodo paralelo.
	double Vtref;  // Tensão térmica de refrência.
	// Variáveis de cálculo
	double Is;     // Valor de fante de corrente
	double Rs, Rp; // Resistências série e paralelo
	double I0;     // Ganho de corrente. Modelo do Diodo paralelo.
	double Vt;     // Tensão térmica. Modelo do diodo paralelo.
	double n;      // Fator de idealidade.  Modelo do diodo paralelo.
	// Configuração do painel
	double G;      // Insolação (W/m²).
	double T;      // Temperatura (K).
	int Ns;        // Número de células em série
	// Parâmetros da resolução iterativa
	int itrLimit;  // Limite de iterações
	double eMax;   // Limite de erro
	
	// Atualização dos parâmetros
	void cfgI0() { I0=i0ref*pow(T/Tref,3)*std::exp(e/(n/Ns)*(1/Vtref-1/Vt)); }
	void cfgVt() { Vt=K*T/q; }
	void cfgIs() { Is=G*isref/gref; }
	
	// Funções de auxílio ao método de resolução numérica
	public:
	double f(double V, double I) const {
		return Is-I-I0*(std::exp((V+Rs*I)/(n*Vt))-1)-(V+Rs*I)/Rp;
	}
	double dfdv(double V, double I) const {
		return -I0/(n*Vt)*std::exp((V+Rs*I)/(n*Vt))-1/Rp;
	}
	double dfdi(double V, double I) const {
		return -1-(I0*Rs)/(n*Vt)*std::exp((V+Rs*I)/(n*Vt))-Rs/Rp;
	}
	double g(double V, double I) const {
		return -I+(V-Rs*I)*(1/Rp+I0/(n*Vt)*std::exp((V+Rs*I)/(n*Vt)));
	}
	double dgdv(double V, double I) const {
		return I0/(n*Vt)*((V+Rs*I)/(n*Vt)+1)*std::exp((V+Rs*I)/(n*Vt))+1/Rp;
	}
	double dgdi(double V, double I) const {
		return ((V-Rs*I)/(n*Vt)-1)*Rs*I0/(n*Vt)*std::exp((V+Rs*I)/(n*Vt))-Rs/Rp-1;
	}
	
	public:
	pvGenerator() {
		itrLimit=100; eMax=1e-7;
		isref=gref=i0ref=Tref=1;
		Is=Rs=Rp=I0=Vt=G=T=1;
		Ns=1;
	}
	void setIterationParameters(int nil, double e) { itrLimit=nil; eMax=e; }
	void setNs(int nns) { Ns=nns; cfgI0(); }
	void setSourceReference(double nisref, double ngref) { isref=nisref; gref=ngref; }
	void setDiodeModel(double ni0ref, double nTref, double nn) {
		i0ref = ni0ref;
		Tref = nTref;
		n=nn;
		Vtref = K*Tref / q;
		cfgI0();
	}
	void setInsolation(double ng) { G=ng; cfgIs(); }
	void setTemperature(double nt) { T=nt; cfgVt(); cfgI0(); }
	void setSeriesCellCount(int n) { Ns=n; cfgI0(); }
	void setRs(double nrs) { Rs=nrs; }
	void setRp(double nrp) { Rp=nrp; }
	
	double V(double I, double v_old=0) const; // Resolve V de I
	double I(double V, double i_old=0) const; // Resolve I de V
	double Vmp(double Imp) const; // Resolve Vmp de Imp
	double Imp(double Vmp) const; // Resolve Imp de Vmp
	// Leituras
	// Referências padrão
	double getSourceCurrentReference() const { return isref; }
	double getInsolationReference() const { return gref; }
	double getDiodeCurrentGainReference() const { return i0ref; }
	double getTemperatureReference() const { return Tref; }
	double getThermalVoltageReference() const { return Vtref; }
	// Variáveis de cálculo
	double getSourceCurrent() const { Is; }
	double getRs() const { return Rs; }
	double getRp() const { return Rp; }
	double getDiodeCurrentGain() const { return I0; }
	double getThermalVoltage() const { return Vt; }
	double getDiodeIdealityFactor() const { return n; }
	// Configuração do painel
	double getInsolation() const { return G; }
	double getTemperature() const { return T; }
	int getSeriesCellCount() const { return Ns; }
	// Parâmetros da resolução iterativa
	int getIterationCountLimit() const { return itrLimit; }
	double getIterationErrorLimit() const { return eMax; }
	
	// 
	void fixup() {
		cfgI0();
		cfgVt();
		cfgIs();
	}
};

#endif
