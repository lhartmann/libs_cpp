/***************************************************************************
 *   Copyright (C) 2007 by Lucas Vinicius Hartmann                         *
 *   lucas.hartmann@gmail.com                                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

// pvGenerator.cpp
#include "pvgen.h"

double pvGenerator::V(double I, double vn) const { // Resolve V de I
	double vo=-100;
	int itr=itrLimit;
	while (itr--) {
		vn -= f(vn,I)/dfdv(vn,I);
		if (fabs(vn-vo)<fabs(eMax*vo)) return vn;
		vo=vn;
	}
}
double pvGenerator::I(double V, double in) const { // Resolve I de V
	double io=-100;
	int itr=itrLimit;
	while (itr--) {
		in -= f(V,in)/dfdi(V,in);
		if (fabs(in-io)<fabs(eMax*io)) return in;
		io=in;
	}
}

/*double pvGenerator::Vmp(double Imp) const { // Resolve V de I
	double vo=25, vn=0;
	double yo=g(vo,Imp);
	int itr=itrLimit;
	// x -= Y dx/dy
	while (itr--) {
		double yn = g(vn,Imp);
		double d = yn*(vn-vo)/(yn-yo);
		yo=yn; vo=vn; vn-=d;
		
		if (fabs(d)<eMax) return vn;
	}
	return -1;
}//*/
double pvGenerator::Vmp(double Imp) const { // Resolve V de I
	double vo=-100, vn=100;
	int itr=itrLimit;
	while (itr--) {
		vn -= g(vn,Imp)/dgdv(vn,Imp);
		if (fabs(vn-vo)<eMax) return vn;
		vo=vn;
	}
	return -1;
}//*/
double pvGenerator::Imp(double Vmp) const { // Resolve I de V
	double io=25, in=0;
	double yo=g(Vmp,io);
	int itr=itrLimit;
	// x -= Y dx/dy
	while (itr--) {
		double yn = g(Vmp,in);
		double d = yn*(in-io)/(yn-yo);
		yo=yn; io=in; in-=d;
		
		if (fabs(d)<eMax) return in;
	}
	return -1;
}
/*double pvGenerator::Imp(double Vmp) const { // Resolve I de V
	double io=-100, in=0;
	int itr=itrLimit;
	while (itr--) {
		in -= g(Vmp,in)/dgdi(Vmp,in);
		if (fabs(in-io)<eMax) return in;
		io=in;
	}
	return -1;
}*/

const double pvGenerator::q = 1.602177e-19;
//const double pvGenerator::K = 1.380658e-23;
const double pvGenerator::K = 1.3854e-23;
const double pvGenerator::e = 1.12;
